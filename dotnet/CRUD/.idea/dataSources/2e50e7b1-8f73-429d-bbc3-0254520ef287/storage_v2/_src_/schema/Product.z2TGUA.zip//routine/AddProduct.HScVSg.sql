create
    definer = root@localhost procedure AddProduct(IN Name varchar(225), IN Description varchar(500), IN Qty int,
                                                  IN Price int)
BEGIN
    INSERT INTO Product (name, description, qty, price)
    VALUES (Name, Description, Qty, Price);
END;

