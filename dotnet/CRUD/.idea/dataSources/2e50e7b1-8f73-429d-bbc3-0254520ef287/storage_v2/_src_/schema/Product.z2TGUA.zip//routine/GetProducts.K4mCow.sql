create
    definer = root@localhost procedure GetProducts()
BEGIN
    SELECT *
    FROM Product;
END;

