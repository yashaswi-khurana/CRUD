create
    definer = root@localhost procedure UpdateProduct(IN Id int, IN Name varchar(225), IN Description varchar(500),
                                                     IN Qty int, IN Price int)
BEGIN
    UPDATE Product
    SET name = Name,
        description = Description,
        qty = Qty,
        price = Price
    WHERE (Product.id = Id);
END;

