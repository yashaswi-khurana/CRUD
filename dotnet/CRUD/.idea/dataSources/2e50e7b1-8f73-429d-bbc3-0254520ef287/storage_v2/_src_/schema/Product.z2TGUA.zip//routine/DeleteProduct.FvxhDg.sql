create
    definer = root@localhost procedure DeleteProduct(IN Id int)
BEGIN
    DELETE FROM Product where Product.id=Id;
END;

