create
    definer = root@localhost procedure GetProductById(IN Id int)
BEGIN
    SELECT * FROM Product where Product.Product.id=Id;
END;

